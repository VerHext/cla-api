
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'verhext',
  applicationName: 'cla-api',
  appUid: 'LSs7q7R85t2JRDqkw6',
  orgUid: 'cfBHWNWtfY72t8VHlN',
  deploymentUid: 'dba5ca85-404f-4cba-9e5d-f0aa0a4c0d60',
  serviceName: 'cla-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.9',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cla-api-dev-api-cla', timeout: 6 };

try {
  const userHandler = require('./sls-next-build/api/cla.js');
  module.exports.handler = serverlessSDK.handler(userHandler.render, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}